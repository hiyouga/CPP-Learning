﻿#include "stdafx.h"
#include "linklist.h"

void init(LinkList);
void insert(LinkList);
void view(LinkList);
void sort(LinkList);
void query(LinkList);
void stat(LinkList);
void del(LinkList);
void modify(LinkList);
void save(LinkList);
void load(LinkList);

int main()
{
    setlocale(LC_ALL, "");
    LinkList head = (LinkList)malloc(sizeof(LinkNode));
    head -> nxt = NULL;
    init(head);
    system("pause");
    return 0;
}

void init(LinkList t)
{
	int menu;
	printf("\n\t%ls\n\n",L"欢迎使用图书信息管理系统！");
    do{
        printf(" -------------\n");
    	printf(" |%-7ls|\n",L"1.录入数据");
    	printf(" |%-7ls|\n",L"2.浏览数据");
    	printf(" |%-9ls|\n",L"3.排序");
    	printf(" |%-7ls|\n",L"4.查询数据");
    	printf(" |%-7ls|\n",L"5.统计数据");
    	printf(" |%-7ls|\n",L"6.删除数据");
    	printf(" |%-7ls|\n",L"7.修改数据");
    	printf(" |%-7ls|\n",L"8.保存数据");
    	printf(" |%-7ls|\n",L"9.读入数据");
    	printf(" |%-7ls|\n",L"0.退出程序");
        printf(" -------------\n");
        printf("%ls",L"请输入选项(0-9)：");
	    scanf("%d", &menu);
	    fflush(stdin);
	    switch(menu)
	    {
	    	case 1:insert(t);break;
	    	case 2:view(t);break;
	    	case 3:sort(t);break;
	    	case 4:query(t);break;
	    	case 5:stat(t);break;
	    	case 6:del(t);break;
	    	case 7:modify(t);break;
	    	case 8:save(t);break;
	    	case 9:load(t);break;
	    	case 0:break;
	    	default:printf("%ls\n",L"输入错误");
	    }
    }while(menu);
}

void insert(LinkList t)
{
	LinkNode r;
	r.nxt = NULL;
	printf("%ls",L"图书编号：");scanf("%d", &r.aid);fflush(stdin);
	printf("%ls",L"书名：");_getws(r.name);
	printf("%ls",L"作者：");_getws(r.auth);
	printf("%ls",L"出版社：");_getws(r.pub);
	printf("%ls",L"出版时间：");scanf("%d", &r.time);
	printf("%ls",L"价格：");scanf("%lf", &r.price);
	fflush(stdin);
	InsertList(t, &r);
}

void view(LinkList t)
{
    DispList(t);
}

void sort(LinkList t)
{
    SortList(t);
    printf("%ls\n",L"排序完成！");
}

void query(LinkList t)
{
    int w;
    printf("%ls\n",L"1.按图书编号");
    printf("%ls\n",L"2.按作者");
    scanf("%d", &w);
    if(w == 1){
        int id;
        printf("%ls",L"图书编号：");
        scanf("%d", &id);
        FindListId(t, id);
    }else if(w == 2){
        wchar_t au[MAXN];
        printf("%ls",L"作者：");
        scanf("%ls", au);
        FindListAuth(t, au);
    }else{
        printf("%ls\n",L"输入错误");
    }
    fflush(stdin);
}

void stat(LinkList t)
{
    wchar_t pu[MAXN];
    printf("%ls",L"出版社：");
    scanf("%ls", pu);
    fflush(stdin);
    StatList(t, pu);
}

void del(LinkList t)
{
    int id;
    printf("%ls",L"图书编号：");scanf("%d", &id);
    fflush(stdin);
    DeleteList(t, id);
    printf("%ls\n",L"删除成功！");
}

void modify(LinkList t)
{
    int id;
    LinkNode r;
    printf("%ls",L"图书编号：");scanf("%d", &id);
    fflush(stdin);
	r.nxt = NULL;
	r.aid = id;
	printf("%ls",L"书名：");scanf("%ls", r.name);
	printf("%ls",L"作者：");scanf("%ls", r.auth);
	printf("%ls",L"出版社：");scanf("%ls", r.pub);
	printf("%ls",L"出版时间：");scanf("%d", &r.time);
	printf("%ls",L"价格：");scanf("%lf", &r.price);
	fflush(stdin);
    ModifyList(t, &r);
}

void save(LinkList t)
{
	FILE * fp;
	if ((fp = fopen("book.data", "wb")) == NULL) {
        fprintf(stderr, "Cannot open data file.\n");
        return;
    }
    while(t -> nxt != NULL){
    	fwrite(t -> nxt, sizeof(LinkNode), 1, fp);
    	t = t -> nxt;
    }
    printf("%ls\n",L"保存成功！");
    fclose(fp);
}

void load(LinkList t)
{
	FILE * fp;
	LinkNode buf;
    if ((fp = fopen("book.data", "rb")) == NULL) {
        fprintf(stderr, "Cannot open data file.\n");
        return;
    }
    DestroyList(t);///删除旧表
	while(fread(&buf, sizeof(LinkNode), 1, fp)){
        buf.nxt = NULL;///防止建表错误
    	InsertList(t, &buf);
	}
	printf("%ls\n",L"读取成功！");
    fclose(fp);
}
