﻿// stdafx.h : Commonly used C header file

#ifndef STDAFX_H_INCLUDED
#define STDAFX_H_INCLUDED

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include <wchar.h>
#include <signal.h>
#include <stddef.h>
#include <locale.h>
#include <windows.h>
#define MAXN 200
#define MAXSIZE 500

#endif // STDAFX_H_INCLUDED
